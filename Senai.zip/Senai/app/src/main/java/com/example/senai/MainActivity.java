package com.example.senai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    public String editText1;
    public String editText2;
    public String editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void onClickBtnMostrar(View v) {
        EditText editText1 = findViewById(R.id.et_texto);
        EditText editText2 = findViewById(R.id.et_texto1);
        // editText1.getText()
        // System.out.println("editText1".concat."editText2".concat)
        String editText3 = editText1.getText().toString() + editText2.getText().toString();
        Toast.makeText(MainActivity.this, editText3,Toast.LENGTH_LONG).show();

    }
    public void onClickBtnLimpar(View v) {
        EditText editText1 = findViewById(R.id.et_texto);
        editText1.setText("");
        EditText editText2 = findViewById(R.id.et_texto1);
        editText2.setText("");
    }

}